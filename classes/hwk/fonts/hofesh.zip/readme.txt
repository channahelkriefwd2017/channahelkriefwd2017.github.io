..........................
      o          o
.ooo..o..o..ooo..o...oooo.
o   o o.o  o ..  o   .oo.
.ooo..o..o..ooo...oo.ooooo

BEST  QUALITY  SINCE  1998
http://www.oketz.com/fonts
FREE HEBREW FONT DOWNLOAD!
THE BEST  o-9  DAY  FONTz!
=-=-=-:This release:-=-=-=
          HOFESH
      for Windows 95+
    Regular + X Version
=-=-=-=-=-=--=-=-=-=-=-=-=
An undeveloped version for
the   "Choco"   font.   In
essence,   the concept was
making a more relaxed font
than the square  shapes of
Choco.   The result wasn't
for my liking,   so I went
in  a different  direction
with  this   writing  than
expected.    "Hofesh"   is
freedom     in      Hebrew.
=-=-=-=-=-=--=-=-=-=-=-=-=
Copyright � MeiR SaDaN (!)
