..........................
      o          o
.ooo..o..o..ooo..o...oooo.
o   o o.o  o ..  o   .oo.
.ooo..o..o..ooo...oo.ooooo

BEST  QUALITY  SINCE  1998
http://www.oketz.com/fonts
FREE HEBREW FONT DOWNLOAD!
THE BEST  o-9  DAY  FONTz!
=-=-=-:This release:-=-=-=
          CHOCO
      for Windows 95+
    Regular + X Version
=-=-=-=-=-=--=-=-=-=-=-=-=
My   original  handwriting,
sketched  using   a  black
marker  on  a  white  page.
Letters  have  been refash-
ioned  in  Fontographer to
give  it  a  squared appea-
rance, and so there's this
weird typeface, that's not
entirely  squared  and yet
not entirely cursive, that
holds a caricaturistic nat-
ure  of  some kind.   This
typeface  reminded  me  of
something infantile, which
is  why  I named it  after
the most childish beverage
in   Israel    -   "Choco"
(Chocolate           Milk).
=-=-=-=-=-=--=-=-=-=-=-=-=
Copyright � MeiR SaDaN (!)
