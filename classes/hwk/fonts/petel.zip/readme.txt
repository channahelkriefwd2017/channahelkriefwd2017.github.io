..........................
      o          o
.ooo..o..o..ooo..o...oooo.
o   o o.o  o ..  o   .oo.
.ooo..o..o..ooo...oo.ooooo

BEST  QUALITY  SINCE  1998
http://www.oketz.com/fonts
FREE HEBREW FONT DOWNLOAD!
THE BEST  o-9  DAY  FONTz!
=-=-=-:This release:-=-=-=
          PETEL
      for Windows 95+
    Regular + X Version
=-=-=-=-=-=--=-=-=-=-=-=-=
As a gesture to the sucess
of the  "Choco"  font,   I
drew these  letters,  that
hold  a better resemblence
to  my  true   handwriting.
This font  was also  drawn
by hand, using a black mar-
ker on a white page.  This
time,  I drew both weights
by hand, instead of artifi-
cially   change    weights
using a computer, by using
two differently shaped mar-
kers.  I  also added a spe-
cial dingbat, with illustr-
ations  that may accompany
text written in  this font,
and   also   independently.
"Petel"      (raspberries),
another very Israeli drink,
looked like the  best name
for  an "answer" to  Choco.
=-=-=-=-=-=--=-=-=-=-=-=-=
Copyright � MeiR SaDaN (!)
